* Setup DB
`DATABASE_URL=db.sql diesel migration run`
* Run server
`DATABASE_URL=db.sql cargo run`
